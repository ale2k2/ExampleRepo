package alexbillini.pantry2me;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HelpedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_helped);
    }
}